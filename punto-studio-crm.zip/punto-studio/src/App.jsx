import { useState, useEffect } from "react";

// ══════════════════════════════════════════════════════════════════
//  DATOS DEL NEGOCIO
// ══════════════════════════════════════════════════════════════════
const STUDIO = {
  name: "Punto Studio",
  handle: "@punto_studioo",
  address: "Plaza Tabachines, Cuernavaca, Mor. 62446",
};

const COLLABORATORS = [
  { name: "Santiago", role: "Barbero",             color: "#7CB9E8", initials: "SA" },
  { name: "Alexia",   role: "Estilista",            color: "#F4A7B9", initials: "AL" },
  { name: "Iris",     role: "Manicura & Pedicura", color: "#A8D8A8", initials: "IR" },
  { name: "Mia",      role: "Manicura & Pedicura", color: "#FFDAB9", initials: "MI" },
  { name: "Paola",    role: "Pestañas & Cejas",    color: "#C3B1E1", initials: "PA" },
];
const COL_MAP = Object.fromEntries(COLLABORATORS.map(c => [c.name, c]));

const SERVICES = [
  { id:"barberia",    label:"Servicio de Barbería",   icon:"✦",  price:180, priceMax:null, duration:45,  collab:["Santiago"] },
  { id:"delineado",   label:"Delineado de Ceja",      icon:"◌",  price:100, priceMax:null, duration:30,  collab:["Paola"] },
  { id:"tinte",       label:"Aplicación de Tintes",   icon:"◈",  price:400, priceMax:null, duration:90,  collab:["Alexia"] },
  { id:"corte_mujer", label:"Corte de Cabello Mujer", icon:"✂",  price:180, priceMax:null, duration:45,  collab:["Alexia"] },
  { id:"efectos",     label:"Efectos de Color",       icon:"◉",  price:600, priceMax:null, duration:120, collab:["Alexia"] },
  { id:"pedicure",    label:"Pedicure",               icon:"◆",  price:200, priceMax:400,  duration:60,  collab:["Iris","Mia"] },
  { id:"manicure",    label:"Manicure",               icon:"◇",  price:200, priceMax:400,  duration:60,  collab:["Iris","Mia"] },
  { id:"acrilicas",   label:"Uñas Acrílicas",         icon:"⬡",  price:200, priceMax:400,  duration:90,  collab:["Iris","Mia"] },
  { id:"gelish",      label:"Gelish (pies y manos)",  icon:"⬟",  price:200, priceMax:400,  duration:75,  collab:["Iris","Mia"] },
  { id:"pestanas",    label:"Aplicación de Pestañas", icon:"⌂",  price:350, priceMax:null, duration:60,  collab:["Paola"] },
  { id:"diseno_ceja", label:"Diseño de Cejas",        icon:"⌁",  price:120, priceMax:null, duration:30,  collab:["Paola"] },
  { id:"cafe",        label:"Coffee Bar",             icon:"☕", price:50,  priceMax:null, duration:10,  collab:["Santiago","Alexia","Iris","Mia","Paola"] },
];
const SVC_MAP = Object.fromEntries(SERVICES.map(s => [s.id, s]));

const STATUS_CFG = {
  pendiente:  { bg:"#1a1c26", text:"#8892a4", dot:"#3d4459" },
  confirmada: { bg:"#0d2218", text:"#4ade80", dot:"#22c55e" },
  "en curso": { bg:"#231c08", text:"#fbbf24", dot:"#f59e0b" },
  completada: { bg:"#0d1829", text:"#60a5fa", dot:"#3b82f6" },
  cancelada:  { bg:"#250e0e", text:"#f87171", dot:"#ef4444" },
};

// ══════════════════════════════════════════════════════════════════
//  DATOS INICIALES (solo se usan la primera vez)
// ══════════════════════════════════════════════════════════════════
const SEED_CLIENTS = [
  { id:1, name:"Valentina Morales", phone:"777-111-2233", email:"vale@mail.com",  stylist:"Alexia",   services:["tinte","efectos","manicure"],       visits:11, lastVisit:"2026-04-18", notes:"Mechas frías. Sensible al cloro.",      totalSpent:9400,  initials:"VM" },
  { id:2, name:"Óscar Reyes",       phone:"777-222-3344", email:"oscar@mail.com", stylist:"Santiago", services:["barberia"],                          visits:20, lastVisit:"2026-04-20", notes:"Degradado bajo + barba perfilada.",     totalSpent:3600,  initials:"OR" },
  { id:3, name:"Camila Torres",     phone:"777-333-4455", email:"cami@mail.com",  stylist:"Iris",     services:["manicure","pedicure","acrilicas"],   visits:8,  lastVisit:"2026-04-14", notes:"Acrílicas largas. Siempre color nude.", totalSpent:5600,  initials:"CT" },
  { id:4, name:"Renata Guzmán",     phone:"777-444-5566", email:"rena@mail.com",  stylist:"Paola",    services:["pestanas","diseno_ceja","delineado"], visits:6,  lastVisit:"2026-04-10", notes:"Pestañas efecto natural.",              totalSpent:3420,  initials:"RG" },
  { id:5, name:"Jimena Salinas",    phone:"777-555-6677", email:"jime@mail.com",  stylist:"Mia",      services:["gelish","pedicure"],                 visits:14, lastVisit:"2026-04-19", notes:"Gelish tonos oscuros.",                 totalSpent:6300,  initials:"JS" },
  { id:6, name:"Diego Hernández",   phone:"777-666-7788", email:"diego@mail.com", stylist:"Santiago", services:["barberia"],                          visits:18, lastVisit:"2026-04-20", notes:"Barba larga, aceite de argán.",          totalSpent:3240,  initials:"DH" },
];

const SEED_APPTS = [
  { id:1, clientId:1, clientName:"Valentina Morales", service:"tinte",    date:"2026-04-21", time:"09:30", stylist:"Alexia",   price:400, status:"completada", notes:"" },
  { id:2, clientId:2, clientName:"Óscar Reyes",       service:"barberia", date:"2026-04-21", time:"10:00", stylist:"Santiago", price:180, status:"completada", notes:"" },
  { id:3, clientId:3, clientName:"Camila Torres",     service:"manicure", date:"2026-04-21", time:"12:00", stylist:"Iris",     price:300, status:"completada", notes:"Rojo acrílico" },
  { id:4, clientId:4, clientName:"Renata Guzmán",     service:"pestanas", date:"2026-04-22", time:"10:00", stylist:"Paola",   price:350, status:"completada", notes:"" },
  { id:5, clientId:5, clientName:"Jimena Salinas",    service:"gelish",   date:"2026-04-22", time:"11:30", stylist:"Mia",     price:250, status:"completada", notes:"" },
];

// ══════════════════════════════════════════════════════════════════
//  PERSISTENCIA — localStorage
// ══════════════════════════════════════════════════════════════════
function useLocalStorage(key, seed) {
  const [state, setState] = useState(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : seed;
    } catch {
      return seed;
    }
  });

  useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(state)); } catch {}
  }, [key, state]);

  return [state, setState];
}

// ══════════════════════════════════════════════════════════════════
//  FECHA HOY (dinámica)
// ══════════════════════════════════════════════════════════════════
const getToday = () => new Date().toISOString().split("T")[0];
const fmt = n => `$${Number(n).toLocaleString("es-MX")}`;

const DAYS_ES = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
const MONTHS_ES = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
const formatDateLong = d => {
  const dt = new Date(d + "T12:00:00");
  return `${DAYS_ES[dt.getDay()]} · ${dt.getDate()} de ${MONTHS_ES[dt.getMonth()]} ${dt.getFullYear()}`;
};

// ══════════════════════════════════════════════════════════════════
//  DESIGN TOKENS
// ══════════════════════════════════════════════════════════════════
const C = {
  bg:    "#080b12",
  panel: "#0c1018",
  card:  "#0f1420",
  border:"#181e2e",
  b2:    "#1c2233",
  text:  "#dce4f0",
  muted: "#3d4f6b",
  dim:   "#1e2a3e",
  accent:"#c8b89a",
};

const css = `
  @import url('https://fonts.googleapis.com/css2?family=Italiana&family=Jost:wght@300;400;500;600;700&display=swap');
  *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }
  html, body, #root { height:100%; background:${C.bg}; }
  ::-webkit-scrollbar { width:3px; }
  ::-webkit-scrollbar-track { background:${C.panel}; }
  ::-webkit-scrollbar-thumb { background:${C.b2}; border-radius:99px; }
  select option { background:${C.card}; color:${C.text}; }
  input[type=number]::-webkit-inner-spin-button { opacity:0; }
  input[type=date]::-webkit-calendar-picker-indicator,
  input[type=time]::-webkit-calendar-picker-indicator { filter:invert(0.35); cursor:pointer; }
`;

// ══════════════════════════════════════════════════════════════════
//  ATOMS
// ══════════════════════════════════════════════════════════════════
const Label = ({ children, mb=10 }) => (
  <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:10.5, fontWeight:700, letterSpacing:"0.16em", textTransform:"uppercase", marginBottom:mb }}>{children}</div>
);

const Avatar = ({ initials, color="#dce4f0", size=38 }) => (
  <div style={{ width:size, height:size, borderRadius:"50%", background:`${color}18`, border:`1.5px solid ${color}40`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, fontFamily:"'Jost',sans-serif", fontWeight:700, fontSize:size*0.32, color, letterSpacing:"0.05em" }}>{initials}</div>
);

const Badge = ({ label, color }) => (
  <span style={{ background:`${color}15`, border:`1px solid ${color}35`, color, borderRadius:4, padding:"2px 9px", fontSize:11, fontFamily:"'Jost',sans-serif", fontWeight:600, letterSpacing:"0.03em", whiteSpace:"nowrap" }}>{label}</span>
);

const Card = ({ children, style }) => (
  <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:24, ...style }}>{children}</div>
);

const Inp = ({ style, ...p }) => (
  <input style={{ background:C.panel, border:`1px solid ${C.border}`, color:C.text, padding:"10px 14px", borderRadius:8, fontFamily:"'Jost',sans-serif", fontSize:13, outline:"none", width:"100%", ...style }} {...p} />
);

const Sel = ({ children, style, ...p }) => (
  <select style={{ background:C.panel, border:`1px solid ${C.border}`, color:C.text, padding:"10px 14px", borderRadius:8, fontFamily:"'Jost',sans-serif", fontSize:13, outline:"none", width:"100%", cursor:"pointer", ...style }} {...p}>{children}</select>
);

const Btn = ({ children, variant="primary", style, ...p }) => {
  const v = variant==="primary"
    ? { background:C.text, color:C.bg, border:"none" }
    : { background:"none", color:C.muted, border:`1px solid ${C.border}` };
  return <button style={{ ...v, padding:"10px 22px", borderRadius:8, cursor:"pointer", fontFamily:"'Jost',sans-serif", fontWeight:600, fontSize:13, letterSpacing:"0.03em", ...style }} {...p}>{children}</button>;
};

const PageHeader = ({ sup, title, right }) => (
  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end" }}>
    <div>
      <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:10.5, fontWeight:700, letterSpacing:"0.16em", textTransform:"uppercase", marginBottom:6 }}>{sup}</div>
      <h2 style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:38, fontWeight:400, lineHeight:1 }}>{title}</h2>
    </div>
    {right}
  </div>
);

// ══════════════════════════════════════════════════════════════════
//  DASHBOARD
// ══════════════════════════════════════════════════════════════════
function Dashboard({ clients, appointments }) {
  const TODAY = getToday();
  const todayA  = appointments.filter(a => a.date === TODAY);
  const revenue = clients.reduce((s,c)=>s+c.totalSpent,0);
  const avgV    = clients.length ? Math.round(clients.reduce((s,c)=>s+c.visits,0)/clients.length) : 0;

  const svcCount = {};
  clients.forEach(c=>c.services.forEach(s=>{svcCount[s]=(svcCount[s]||0)+1;}));
  const topSvc = Object.entries(svcCount).sort((a,b)=>b[1]-a[1]).slice(0,6);
  const maxSvc = topSvc[0]?.[1]||1;

  const collabLoad = {};
  COLLABORATORS.forEach(c=>{collabLoad[c.name]=appointments.filter(a=>a.stylist===c.name).length;});
  const maxLoad = Math.max(...Object.values(collabLoad),1);

  // Ingresos del día (solo citas completadas de hoy)
  const todayRevenue = todayA.filter(a=>a.status==="completada").reduce((s,a)=>s+a.price,0);

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:28 }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end" }}>
        <div>
          <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:10.5, fontWeight:700, letterSpacing:"0.16em", textTransform:"uppercase", marginBottom:6 }}>{formatDateLong(TODAY)}</div>
          <h2 style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:38, fontWeight:400 }}>Panel de Control</h2>
        </div>
        <div style={{ textAlign:"right" }}>
          <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:12, marginBottom:4 }}>{STUDIO.address}</div>
          <div style={{ display:"flex", alignItems:"center", gap:6, justifyContent:"flex-end" }}>
            <div style={{ width:7, height:7, borderRadius:"50%", background:"#22c55e", boxShadow:"0 0 8px #22c55e90" }} />
            <span style={{ color:"#22c55e", fontFamily:"'Jost',sans-serif", fontSize:12 }}>Estudio activo</span>
          </div>
        </div>
      </div>

      {/* KPIs */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(150px,1fr))", gap:12 }}>
        {[
          { l:"Clientes",          v:clients.length,      s:`${clients.filter(c=>c.visits>=8).length} frecuentes` },
          { l:"Citas hoy",         v:todayA.length,       s:`${todayA.filter(a=>a.status==="confirmada"||a.status==="en curso").length} activas` },
          { l:"Ingresos hoy",      v:fmt(todayRevenue),   s:"citas completadas" },
          { l:"Ingresos totales",  v:fmt(revenue),        s:"acumulado" },
          { l:"Colaboradores",     v:COLLABORATORS.length, s:"activos" },
        ].map((k,i)=>(
          <div key={i} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:"20px 22px", position:"relative", overflow:"hidden" }}>
            <div style={{ position:"absolute", top:0, left:12, right:12, height:1, background:`linear-gradient(90deg,transparent,${C.muted}50,transparent)` }} />
            <Label mb={8}>{k.l}</Label>
            <div style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:30, lineHeight:1 }}>{k.v}</div>
            <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:11, marginTop:5 }}>{k.s}</div>
          </div>
        ))}
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"3fr 2fr", gap:16 }}>
        <Card>
          <Label>Servicios más solicitados</Label>
          {topSvc.length === 0
            ? <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:13 }}>Sin datos aún. Agrega clientes para ver estadísticas.</div>
            : <div style={{ display:"flex", flexDirection:"column", gap:13 }}>
                {topSvc.map(([id,count])=>{
                  const s=SVC_MAP[id]; if(!s) return null;
                  return (
                    <div key={id}>
                      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5 }}>
                        <span style={{ color:"#94a3b8", fontFamily:"'Jost',sans-serif", fontSize:13 }}>{s.icon} {s.label}</span>
                        <span style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:12 }}>{count}</span>
                      </div>
                      <div style={{ background:C.dim, borderRadius:99, height:3 }}>
                        <div style={{ width:`${(count/maxSvc)*100}%`, height:"100%", background:C.accent, borderRadius:99, opacity:0.85 }} />
                      </div>
                    </div>
                  );
                })}
              </div>
          }
        </Card>
        <Card>
          <Label>Carga por colaborador</Label>
          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
            {COLLABORATORS.map(co=>{
              const cnt=collabLoad[co.name]||0;
              return (
                <div key={co.name}>
                  <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5, alignItems:"center" }}>
                    <div style={{ display:"flex", gap:7, alignItems:"center" }}>
                      <div style={{ width:7, height:7, borderRadius:"50%", background:co.color }} />
                      <span style={{ color:"#94a3b8", fontFamily:"'Jost',sans-serif", fontSize:13 }}>{co.name}</span>
                    </div>
                    <span style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:11 }}>{cnt}</span>
                  </div>
                  <div style={{ background:C.dim, borderRadius:99, height:3 }}>
                    <div style={{ width:`${(cnt/maxLoad)*100}%`, height:"100%", background:co.color, borderRadius:99 }} />
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Agenda hoy */}
      <Card>
        <Label>Agenda de hoy — {todayA.length} cita{todayA.length!==1?"s":""}</Label>
        {todayA.length===0
          ? <span style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:14 }}>No hay citas programadas para hoy.</span>
          : <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
              {todayA.sort((a,b)=>a.time.localeCompare(b.time)).map(a=>{
                const sc=STATUS_CFG[a.status]||STATUS_CFG.pendiente;
                const svc=SVC_MAP[a.service]; const co=COL_MAP[a.stylist];
                return (
                  <div key={a.id} style={{ display:"flex", alignItems:"center", gap:14, padding:"12px 16px", background:C.panel, borderRadius:10, border:`1px solid ${C.border}` }}>
                    <div style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:19, minWidth:50 }}>{a.time}</div>
                    <Avatar initials={a.clientName.split(" ").map(w=>w[0]).join("")} size={34} color={co?.color||C.accent} />
                    <div style={{ flex:1 }}>
                      <div style={{ color:C.text, fontFamily:"'Jost',sans-serif", fontWeight:600, fontSize:14 }}>{a.clientName}</div>
                      <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:12, marginTop:2 }}>{svc?.icon} {svc?.label} · {a.stylist}</div>
                    </div>
                    <div style={{ background:sc.bg, color:sc.text, borderRadius:6, padding:"4px 11px", fontSize:11, fontFamily:"'Jost',sans-serif", fontWeight:700, display:"flex", alignItems:"center", gap:5 }}>
                      <span style={{ width:5, height:5, borderRadius:"50%", background:sc.dot, display:"inline-block" }} />{a.status}
                    </div>
                    <div style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:19, minWidth:68, textAlign:"right" }}>{fmt(a.price)}</div>
                  </div>
                );
              })}
            </div>
        }
      </Card>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
//  CLIENTES
// ══════════════════════════════════════════════════════════════════
function Clients({ clients, setClients, appointments }) {
  const [search,   setSearch]   = useState("");
  const [detail,   setDetail]   = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [confirm,  setConfirm]  = useState(null);
  const [form, setForm] = useState({ name:"", phone:"", email:"", stylist:"Santiago", services:[], notes:"" });

  const filtered = clients.filter(c=>
    c.name.toLowerCase().includes(search.toLowerCase())||
    c.phone.includes(search)||c.email.toLowerCase().includes(search.toLowerCase())
  );

  const toggleSvc = id => setForm(f=>({...f, services:f.services.includes(id)?f.services.filter(x=>x!==id):[...f.services,id]}));

  const save = () => {
    if(!form.name.trim()) return;
    setClients(p=>[...p,{
      id: Date.now(), visits:0, lastVisit: getToday(), totalSpent:0,
      initials: form.name.trim().split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase(),
      ...form
    }]);
    setForm({ name:"", phone:"", email:"", stylist:"Santiago", services:[], notes:"" });
    setShowForm(false);
  };

  const deleteClient = id => {
    setClients(p=>p.filter(c=>c.id!==id));
    setConfirm(null);
    setDetail(null);
  };

  if(detail){
    const c=clients.find(x=>x.id===detail);
    if(!c){setDetail(null); return null;}
    const co=COL_MAP[c.stylist];
    const myAppts=appointments.filter(a=>a.clientId===c.id).sort((a,b)=>`${b.date}${b.time}`.localeCompare(`${a.date}${a.time}`));
    return (
      <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
        <div style={{ display:"flex", gap:10 }}>
          <Btn variant="ghost" style={{ padding:"8px 16px" }} onClick={()=>setDetail(null)}>← Volver</Btn>
          <Btn variant="ghost" style={{ padding:"8px 16px", color:"#f87171", borderColor:"#ef444430" }} onClick={()=>setConfirm(c.id)}>Eliminar cliente</Btn>
        </div>
        {confirm===c.id && (
          <div style={{ background:"#200f0f", border:"1px solid #ef444430", borderRadius:10, padding:"16px 20px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
            <span style={{ color:"#f87171", fontFamily:"'Jost',sans-serif", fontSize:14 }}>¿Eliminar a {c.name} permanentemente?</span>
            <div style={{ display:"flex", gap:10 }}>
              <Btn variant="ghost" style={{ padding:"6px 14px" }} onClick={()=>setConfirm(null)}>Cancelar</Btn>
              <button onClick={()=>deleteClient(c.id)} style={{ background:"#ef4444", border:"none", color:"#fff", padding:"6px 14px", borderRadius:6, cursor:"pointer", fontFamily:"'Jost',sans-serif", fontWeight:600, fontSize:13 }}>Sí, eliminar</button>
            </div>
          </div>
        )}
        <Card>
          <div style={{ display:"flex", gap:18, alignItems:"center", marginBottom:28 }}>
            <Avatar initials={c.initials} size={64} color={co?.color||C.accent} />
            <div>
              <h2 style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:30, fontWeight:400 }}>{c.name}</h2>
              <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:13, marginTop:4 }}>{c.phone} · {c.email}</div>
              <div style={{ display:"flex", gap:8, marginTop:10, flexWrap:"wrap" }}>
                <Badge label={c.stylist} color={co?.color||C.accent} />
                {c.visits>=8 && <Badge label="Cliente frecuente ★" color="#fbbf24" />}
              </div>
            </div>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:12, marginBottom:24 }}>
            {[["Visitas",c.visits],["Total gastado",fmt(c.totalSpent)],["Última visita",c.lastVisit||"—"]].map(([l,v])=>(
              <div key={l} style={{ background:C.panel, borderRadius:10, padding:"16px 18px" }}>
                <Label mb={6}>{l}</Label>
                <div style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:22 }}>{v}</div>
              </div>
            ))}
          </div>
          {c.services.length>0 && <><Label>Servicios</Label>
            <div style={{ display:"flex", flexWrap:"wrap", gap:8, marginBottom:20 }}>
              {c.services.map(id=>{const s=SVC_MAP[id]; return s?<Badge key={id} label={`${s.icon} ${s.label}`} color={C.accent} />:null;})}
            </div></>}
          {c.notes && <><Label>Notas</Label>
            <div style={{ background:C.panel, borderRadius:8, padding:"12px 16px", color:"#8892a4", fontFamily:"'Jost',sans-serif", fontSize:13, lineHeight:1.7, marginBottom:20 }}>{c.notes}</div></>}
          {myAppts.length>0 && <><Label>Historial de citas</Label>
            <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
              {myAppts.map(a=>{
                const sc=STATUS_CFG[a.status]||STATUS_CFG.pendiente;
                const svc=SVC_MAP[a.service];
                return (
                  <div key={a.id} style={{ display:"flex", alignItems:"center", gap:12, padding:"10px 14px", background:C.panel, borderRadius:8, border:`1px solid ${C.border}` }}>
                    <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:12, minWidth:80 }}>{a.date}</div>
                    <div style={{ color:C.text, fontFamily:"'Jost',sans-serif", fontSize:13, flex:1 }}>{svc?.icon} {svc?.label} · {a.stylist}</div>
                    <div style={{ background:sc.bg, color:sc.text, borderRadius:5, padding:"2px 9px", fontSize:11, fontFamily:"'Jost',sans-serif", fontWeight:700 }}>{a.status}</div>
                    <div style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:17, minWidth:60, textAlign:"right" }}>{fmt(a.price)}</div>
                  </div>
                );
              })}
            </div></>}
        </Card>
      </div>
    );
  }

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
      <PageHeader sup="Directorio" title={`Clientes (${clients.length})`} right={<Btn onClick={()=>setShowForm(true)}>+ Nuevo cliente</Btn>} />
      <Inp value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar por nombre, teléfono o email…" />

      {showForm && (
        <Card>
          <h3 style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:24, fontWeight:400, marginBottom:20 }}>Nuevo cliente</h3>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:12 }}>
            <Inp placeholder="Nombre completo *" value={form.name}  onChange={e=>setForm(f=>({...f,name:e.target.value}))}  style={{ gridColumn:"1/-1" }} />
            <Inp placeholder="Teléfono"           value={form.phone} onChange={e=>setForm(f=>({...f,phone:e.target.value}))} />
            <Inp placeholder="Email"              value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} />
          </div>
          <div style={{ marginBottom:14 }}>
            <Label>Colaborador asignado</Label>
            <Sel value={form.stylist} onChange={e=>setForm(f=>({...f,stylist:e.target.value}))}>
              {COLLABORATORS.map(c=><option key={c.name} value={c.name}>{c.name} — {c.role}</option>)}
            </Sel>
          </div>
          <div style={{ marginBottom:14 }}>
            <Label>Servicios de interés</Label>
            <div style={{ display:"flex", flexWrap:"wrap", gap:8 }}>
              {SERVICES.map(s=>(
                <button key={s.id} onClick={()=>toggleSvc(s.id)} style={{
                  background:form.services.includes(s.id)?`${C.accent}20`:C.panel,
                  border:`1px solid ${form.services.includes(s.id)?C.accent:C.border}`,
                  color:form.services.includes(s.id)?C.accent:C.muted,
                  padding:"5px 12px", borderRadius:6, cursor:"pointer",
                  fontFamily:"'Jost',sans-serif", fontSize:12, fontWeight:600,
                }}>{s.icon} {s.label}</button>
              ))}
            </div>
          </div>
          <textarea placeholder="Notas (preferencias, alergias, etc.)" value={form.notes} onChange={e=>setForm(f=>({...f,notes:e.target.value}))}
            style={{ width:"100%", background:C.panel, border:`1px solid ${C.border}`, color:C.text, padding:"10px 14px", borderRadius:8, fontFamily:"'Jost',sans-serif", fontSize:13, outline:"none", resize:"vertical", minHeight:72, boxSizing:"border-box", marginBottom:16 }} />
          <div style={{ display:"flex", gap:10 }}>
            <Btn onClick={save}>Guardar cliente</Btn>
            <Btn variant="ghost" onClick={()=>setShowForm(false)}>Cancelar</Btn>
          </div>
        </Card>
      )}

      <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
        {filtered.map(c=>{
          const co=COL_MAP[c.stylist];
          return (
            <div key={c.id} onClick={()=>setDetail(c.id)}
              style={{ display:"flex", alignItems:"center", gap:14, padding:"14px 18px", background:C.card, border:`1px solid ${C.border}`, borderRadius:12, cursor:"pointer", transition:"border-color 0.15s" }}
              onMouseEnter={e=>e.currentTarget.style.borderColor=C.b2}
              onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}
            >
              <Avatar initials={c.initials} size={40} color={co?.color||C.accent} />
              <div style={{ flex:1 }}>
                <div style={{ color:C.text, fontFamily:"'Jost',sans-serif", fontWeight:600, fontSize:14 }}>{c.name}</div>
                <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:12, marginTop:2 }}>{c.phone} · {co?.name} ({co?.role})</div>
              </div>
              <div style={{ display:"flex", gap:6, flexWrap:"wrap", justifyContent:"flex-end", maxWidth:260 }}>
                {c.services.slice(0,3).map(id=>{const s=SVC_MAP[id]; return s?<Badge key={id} label={s.label} color={C.accent} />:null;})}
                {c.services.length>3 && <Badge label={`+${c.services.length-3}`} color={C.muted} />}
              </div>
              <div style={{ textAlign:"right", minWidth:90 }}>
                <div style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:20 }}>{fmt(c.totalSpent)}</div>
                <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:11, marginTop:1 }}>{c.visits} visitas</div>
              </div>
            </div>
          );
        })}
        {filtered.length===0 && <div style={{ textAlign:"center", padding:48, color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:14 }}>Sin resultados</div>}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
//  AGENDA
// ══════════════════════════════════════════════════════════════════
function Agenda({ appointments, setAppointments, clients, setClients }) {
  const TODAY = getToday();
  const [dayF,  setDayF]  = useState("hoy");
  const [colF,  setColF]  = useState("Todos");
  const [showF, setShowF] = useState(false);
  const [form, setForm]   = useState({ clientId:"", service:"barberia", date:TODAY, time:"10:00", stylist:"Santiago", price:"", notes:"", status:"pendiente" });

  const changeSvc = id => {
    const svc=SVC_MAP[id];
    setForm(f=>({...f, service:id, stylist:svc?.collab?.[0]||f.stylist, price:svc?.price||""}));
  };

  const save = () => {
    const c=clients.find(x=>x.id===parseInt(form.clientId));
    if(!c) return;
    const newAppt = { id:Date.now(), clientName:c.name, ...form, clientId:parseInt(form.clientId), price:parseInt(form.price)||(SVC_MAP[form.service]?.price||0) };
    setAppointments(p=>[...p, newAppt]);
    setForm({ clientId:"", service:"barberia", date:TODAY, time:"10:00", stylist:"Santiago", price:"", notes:"", status:"pendiente" });
    setShowF(false);
  };

  const setStatus = (id, status) => {
    const appt = appointments.find(a=>a.id===id);
    setAppointments(p=>p.map(a=>a.id===id?{...a,status}:a));
    // Si se marca como completada, actualizar visitas y totalSpent del cliente
    if(status==="completada" && appt) {
      setClients(p=>p.map(c=> c.id===appt.clientId
        ? { ...c, visits:c.visits+1, totalSpent:c.totalSpent+appt.price, lastVisit:appt.date }
        : c
      ));
    }
  };

  const deleteAppt = id => setAppointments(p=>p.filter(a=>a.id!==id));

  let list=[...appointments];
  if(dayF==="hoy") list=list.filter(a=>a.date===TODAY);
  if(colF!=="Todos") list=list.filter(a=>a.stylist===colF);
  list.sort((a,b)=>`${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));

  const svcForForm=SVC_MAP[form.service];
  const sugCollabs=svcForForm?.collab||COLLABORATORS.map(c=>c.name);

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
      <PageHeader sup="Agenda" title="Citas" right={<Btn onClick={()=>setShowF(true)}>+ Nueva cita</Btn>} />

      <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
        {["hoy","todas"].map(f=>(
          <button key={f} onClick={()=>setDayF(f)} style={{
            background:dayF===f?C.text:"none", border:`1px solid ${dayF===f?C.text:C.border}`,
            color:dayF===f?C.bg:C.muted, padding:"7px 16px", borderRadius:6,
            cursor:"pointer", fontFamily:"'Jost',sans-serif", fontSize:12, fontWeight:600,
          }}>{f==="hoy"?"Hoy":"Todas"}</button>
        ))}
        <div style={{ width:1, background:C.border, margin:"0 4px" }} />
        {["Todos",...COLLABORATORS.map(c=>c.name)].map(n=>{
          const co=COL_MAP[n]; const active=colF===n;
          return (
            <button key={n} onClick={()=>setColF(n)} style={{
              background:active?`${co?.color||C.accent}18`:"none",
              border:`1px solid ${active?(co?.color||C.accent):C.border}`,
              color:active?(co?.color||C.accent):C.muted,
              padding:"7px 14px", borderRadius:6, cursor:"pointer",
              fontFamily:"'Jost',sans-serif", fontSize:12, fontWeight:600,
            }}>{n}</button>
          );
        })}
      </div>

      {showF && (
        <Card>
          <h3 style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:24, fontWeight:400, marginBottom:20 }}>Nueva cita</h3>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:12 }}>
            <Sel value={form.clientId} onChange={e=>setForm(f=>({...f,clientId:e.target.value}))} style={{ gridColumn:"1/-1" }}>
              <option value="">Seleccionar cliente…</option>
              {clients.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
            </Sel>
            <Sel value={form.service} onChange={e=>changeSvc(e.target.value)}>
              {SERVICES.map(s=><option key={s.id} value={s.id}>{s.icon} {s.label}</option>)}
            </Sel>
            <Sel value={form.stylist} onChange={e=>setForm(f=>({...f,stylist:e.target.value}))}>
              {COLLABORATORS.filter(c=>sugCollabs.includes(c.name)).map(c=><option key={c.name} value={c.name}>{c.name} — {c.role}</option>)}
            </Sel>
            <Inp type="date" value={form.date} onChange={e=>setForm(f=>({...f,date:e.target.value}))} />
            <Inp type="time" value={form.time} onChange={e=>setForm(f=>({...f,time:e.target.value}))} />
            <Inp placeholder={`Precio (desde ${fmt(svcForForm?.price||0)})`} value={form.price} onChange={e=>setForm(f=>({...f,price:e.target.value}))} />
          </div>
          <Inp placeholder="Notas…" value={form.notes} onChange={e=>setForm(f=>({...f,notes:e.target.value}))} style={{ marginBottom:14 }} />
          <div style={{ display:"flex", gap:10 }}>
            <Btn onClick={save}>Agendar</Btn>
            <Btn variant="ghost" onClick={()=>setShowF(false)}>Cancelar</Btn>
          </div>
        </Card>
      )}

      <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
        {list.map(a=>{
          const sc=STATUS_CFG[a.status]||STATUS_CFG.pendiente;
          const svc=SVC_MAP[a.service]; const co=COL_MAP[a.stylist];
          return (
            <div key={a.id} style={{ display:"flex", alignItems:"center", gap:14, padding:"14px 18px", background:C.card, border:`1px solid ${C.border}`, borderRadius:12 }}>
              <div style={{ textAlign:"center", minWidth:52 }}>
                <div style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:20 }}>{a.time}</div>
                {dayF==="todas" && <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:10 }}>{a.date}</div>}
              </div>
              <Avatar initials={a.clientName.split(" ").map(w=>w[0]).join("")} size={36} color={co?.color||C.accent} />
              <div style={{ flex:1 }}>
                <div style={{ color:C.text, fontFamily:"'Jost',sans-serif", fontWeight:600, fontSize:14 }}>{a.clientName}</div>
                <div style={{ display:"flex", gap:6, marginTop:4, flexWrap:"wrap", alignItems:"center" }}>
                  {svc && <Badge label={`${svc.icon} ${svc.label}`} color={C.accent} />}
                  <Badge label={a.stylist} color={co?.color||C.muted} />
                  {a.notes && <span style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:11 }}>· {a.notes}</span>}
                </div>
              </div>
              <Sel value={a.status} onChange={e=>setStatus(a.id,e.target.value)}
                style={{ width:"auto", background:sc.bg, border:`1px solid ${sc.dot}44`, color:sc.text, padding:"5px 10px", borderRadius:6, fontSize:11, fontWeight:700 }}>
                {Object.keys(STATUS_CFG).map(s=><option key={s} value={s}>{s}</option>)}
              </Sel>
              <div style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:20, minWidth:70, textAlign:"right" }}>{fmt(a.price)}</div>
              <button onClick={()=>deleteAppt(a.id)} style={{ background:"none", border:"none", color:C.muted, cursor:"pointer", fontSize:16, padding:"4px 8px" }} title="Eliminar cita">×</button>
            </div>
          );
        })}
        {list.length===0 && <div style={{ textAlign:"center", padding:48, color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:14 }}>Sin citas en este filtro</div>}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
//  CATÁLOGO
// ══════════════════════════════════════════════════════════════════
function Catalogo() {
  const [prices, setPrices] = useLocalStorage("ps_prices", Object.fromEntries(SERVICES.map(s=>[s.id,{min:s.price,max:s.priceMax}])));

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
      <PageHeader sup="Precios" title="Catálogo de Servicios" />
      <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:13, marginTop:-8 }}>
        Los precios que edites aquí se guardan automáticamente en este dispositivo.
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(265px,1fr))", gap:12 }}>
        {SERVICES.map(s=>{
          const p=prices[s.id]||{min:s.price,max:s.priceMax};
          const collabList=s.collab.map(n=>COL_MAP[n]).filter(Boolean);
          return (
            <Card key={s.id} style={{ borderTop:`2px solid ${C.b2}` }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14 }}>
                <div>
                  <div style={{ fontSize:20, marginBottom:6 }}>{s.icon}</div>
                  <div style={{ color:C.text, fontFamily:"'Jost',sans-serif", fontWeight:600, fontSize:14 }}>{s.label}</div>
                  <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:11, marginTop:3 }}>{s.duration} min</div>
                </div>
                <div style={{ display:"flex", flexDirection:"column", gap:4, alignItems:"flex-end" }}>
                  {collabList.map(co=>(
                    <div key={co.name} style={{ display:"flex", alignItems:"center", gap:5 }}>
                      <div style={{ width:6, height:6, borderRadius:"50%", background:co.color }} />
                      <span style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:11 }}>{co.name}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap" }}>
                <span style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:12 }}>Desde</span>
                <input type="number" value={p.min}
                  onChange={e=>setPrices(prev=>({...prev,[s.id]:{...p,min:parseInt(e.target.value)||0}}))}
                  style={{ background:C.panel, border:`1px solid ${C.border}`, color:C.text, padding:"5px 10px", borderRadius:6, fontFamily:"'Italiana',serif", fontSize:18, outline:"none", width:80, textAlign:"right" }} />
                {s.priceMax!==null && <>
                  <span style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:12 }}>hasta</span>
                  <input type="number" value={p.max||""}
                    onChange={e=>setPrices(prev=>({...prev,[s.id]:{...p,max:parseInt(e.target.value)||0}}))}
                    style={{ background:C.panel, border:`1px solid ${C.border}`, color:C.text, padding:"5px 10px", borderRadius:6, fontFamily:"'Italiana',serif", fontSize:18, outline:"none", width:80, textAlign:"right" }} />
                </>}
                <span style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:12 }}>MXN</span>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
//  EQUIPO
// ══════════════════════════════════════════════════════════════════
function Equipo({ appointments, clients }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
      <PageHeader sup="Colaboradores" title="Nuestro Equipo" />
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(275px,1fr))", gap:14 }}>
        {COLLABORATORS.map(co=>{
          const myAppts=appointments.filter(a=>a.stylist===co.name);
          const myClients=clients.filter(c=>c.stylist===co.name);
          const revenue=myAppts.filter(a=>a.status==="completada").reduce((s,a)=>s+a.price,0);
          const TODAY=getToday();
          const todayA=myAppts.filter(a=>a.date===TODAY);
          const myServices=SERVICES.filter(s=>s.collab.includes(co.name));
          return (
            <Card key={co.name} style={{ borderLeft:`2px solid ${co.color}`, position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:-30, right:-30, width:100, height:100, borderRadius:"50%", background:`${co.color}08` }} />
              <div style={{ display:"flex", gap:14, alignItems:"center", marginBottom:20 }}>
                <Avatar initials={co.initials} size={52} color={co.color} />
                <div>
                  <div style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:22 }}>{co.name}</div>
                  <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:12, marginTop:2 }}>{co.role}</div>
                </div>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:16 }}>
                {[["Citas totales",myAppts.length],["Clientes",myClients.length],["Citas hoy",todayA.length],["Ingresos",revenue?fmt(revenue):"$0"]].map(([l,v])=>(
                  <div key={l} style={{ background:C.panel, borderRadius:8, padding:"10px 12px" }}>
                    <div style={{ color:C.muted, fontFamily:"'Jost',sans-serif", fontSize:10, fontWeight:700, letterSpacing:"0.1em", textTransform:"uppercase", marginBottom:4 }}>{l}</div>
                    <div style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:18 }}>{v}</div>
                  </div>
                ))}
              </div>
              <Label>Especialidades</Label>
              <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
                {myServices.map(s=><Badge key={s.id} label={`${s.icon} ${s.label}`} color={co.color} />)}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
//  APP
// ══════════════════════════════════════════════════════════════════
const NAV = [
  { id:"dashboard", icon:"⊞", label:"Panel"    },
  { id:"clientes",  icon:"◎", label:"Clientes" },
  { id:"agenda",    icon:"◷", label:"Agenda"   },
  { id:"catalogo",  icon:"◈", label:"Catálogo" },
  { id:"equipo",    icon:"◉", label:"Equipo"   },
];

export default function App() {
  const [page,         setPage]         = useState("dashboard");
  const [clients,      setClients]      = useLocalStorage("ps_clients",      SEED_CLIENTS);
  const [appointments, setAppointments] = useLocalStorage("ps_appointments", SEED_APPTS);
  const [collapsed,    setCollapsed]    = useState(false);

  return (
    <>
      <style>{css}</style>
      <div style={{ display:"flex", minHeight:"100vh", background:C.bg, fontFamily:"'Jost',sans-serif" }}>

        {/* Sidebar */}
        <aside style={{ width:collapsed?58:220, transition:"width 0.25s ease", background:C.panel, borderRight:`1px solid ${C.border}`, display:"flex", flexDirection:"column", padding:"26px 0", position:"sticky", top:0, height:"100vh", flexShrink:0, overflow:"hidden" }}>
          <div style={{ padding:collapsed?"0 13px 24px":"0 20px 24px", borderBottom:`1px solid ${C.border}`, marginBottom:20 }}>
            <div onClick={()=>setCollapsed(c=>!c)} style={{ display:"flex", alignItems:"center", gap:10, cursor:"pointer" }}>
              <div style={{ width:30, height:30, borderRadius:6, background:C.text, display:"flex", alignItems:"center", justifyContent:"center", color:C.bg, fontFamily:"'Italiana',serif", fontSize:18, flexShrink:0 }}>P</div>
              {!collapsed && (
                <div>
                  <div style={{ fontFamily:"'Italiana',serif", color:C.text, fontSize:18, lineHeight:1.1 }}>Punto Studio</div>
                  <div style={{ fontFamily:"'Jost',sans-serif", color:C.muted, fontSize:9.5, letterSpacing:"0.14em", textTransform:"uppercase", marginTop:3 }}>CRM · Cuernavaca</div>
                </div>
              )}
            </div>
          </div>

          <div style={{ display:"flex", flexDirection:"column", gap:2, padding:"0 8px" }}>
            {NAV.map(n=>{
              const active=page===n.id;
              return (
                <button key={n.id} onClick={()=>setPage(n.id)} style={{
                  display:"flex", alignItems:"center", gap:10,
                  padding:collapsed?"10px 0":"10px 12px", justifyContent:collapsed?"center":"flex-start",
                  borderRadius:8, border:"none", cursor:"pointer",
                  background:active?`${C.text}10`:"none",
                  color:active?C.text:C.muted,
                  fontFamily:"'Jost',sans-serif", fontWeight:active?600:400, fontSize:13,
                  whiteSpace:"nowrap", transition:"color 0.15s",
                  borderLeft:active?`2px solid ${C.text}`:"2px solid transparent",
                }}
                  onMouseEnter={e=>{if(!active)e.currentTarget.style.color="#647486";}}
                  onMouseLeave={e=>{if(!active)e.currentTarget.style.color=C.muted;}}
                >
                  <span style={{ fontSize:15, width:20, textAlign:"center", flexShrink:0 }}>{n.icon}</span>
                  {!collapsed && n.label}
                </button>
              );
            })}
          </div>

          {!collapsed && (
            <div style={{ marginTop:"auto", padding:"18px 20px 0", borderTop:`1px solid ${C.border}` }}>
              <Label>Equipo</Label>
              {COLLABORATORS.map(co=>(
                <div key={co.name} style={{ display:"flex", alignItems:"center", gap:9, padding:"5px 0" }}>
                  <div style={{ width:7, height:7, borderRadius:"50%", background:co.color, flexShrink:0 }} />
                  <div>
                    <div style={{ color:"#647486", fontFamily:"'Jost',sans-serif", fontSize:12, lineHeight:1.2 }}>{co.name}</div>
                    <div style={{ color:C.dim, fontFamily:"'Jost',sans-serif", fontSize:10 }}>{co.role}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </aside>

        {/* Main */}
        <main style={{ flex:1, padding:"40px 44px 60px", overflowY:"auto", minWidth:0 }}>
          {page==="dashboard" && <Dashboard    clients={clients}      appointments={appointments} />}
          {page==="clientes"  && <Clients      clients={clients}      setClients={setClients} appointments={appointments} />}
          {page==="agenda"    && <Agenda        appointments={appointments} setAppointments={setAppointments} clients={clients} setClients={setClients} />}
          {page==="catalogo"  && <Catalogo />}
          {page==="equipo"    && <Equipo        appointments={appointments} clients={clients} />}
        </main>
      </div>
    </>
  );
}
